
import sqlite3
from collections import Counter
from pyodide.ffi import to_js

GET_ALL_TABLES_QUERY = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
GET_TABLE_COUNT_QUERY = "SELECT '{}', count(*) FROM {};"


def _collate_UNICODE(str1, str2):
    if str1 == str2:
        return 0
    elif str1 < str2:
        return -1
    else:
        return 1

def _execute_query(connection, query):
    cur = connection.cursor()
    try:
        cur.execute(query)
    except Exception as e:
        return None, None, str(e)
    return cur.description, cur.fetchall(), None


###################
# Public Functions
###################

def create_database(name, creationQuery):
    connection = sqlite3.connect(name)
    connection.create_collation("UNICODE", _collate_UNICODE)
    connection.executescript(creationQuery)
    connection.commit()
    return connection

def create_databases(names, creation_queries):
    data_base_connections = {}
    for name, query in zip(names, creation_queries):
        data_base_connections[name] = create_database(name, query)
    return data_base_connections

def execute_query(connection, query):
    connection.commit()
    column_names, query_result, exception = _execute_query(connection, query)
    connection.rollback()
    if exception:
        return to_js({'error': exception})
    return to_js({
        'column_names' : [column_name[0] for column_name in column_names] if column_names else [],
        'query_results' : query_result
    })
def execute_query_with_check(connection, query, check_query):
    connection.commit()
    _, _, _ = _execute_query(connection, query)
    column_names, query_result, _ = _execute_query(connection, check_query)
    connection.rollback()
    return to_js({
        'column_names' : [column_name[0] for column_name in column_names] if column_names else [],
        'query_results' : query_result
    })

def get_database_state(connection):
    query_result = []
    _, all_tables, _ = _execute_query(connection, GET_ALL_TABLES_QUERY)
    for table in all_tables:
        table_name = table[0]
        _, result , _= _execute_query(connection, GET_TABLE_COUNT_QUERY.format(table_name, table_name))
        query_result.append(result)

    return to_js({
        'column_names' : ['', ''],
        'query_results' : query_result
        })

def compare_select_query_results(connection, solution_query, test_query, check_if_columns_match):
    connection.commit()
    column_names1, result1, _ = _execute_query(connection, solution_query)
    connection.rollback()
    column_names2, result2, err2 = _execute_query(connection, test_query)
    connection.rollback()

    if err2:
        return to_js({'error': err2})

    if check_if_columns_match and column_names1 != column_names2:
        return to_js({'query_results' : False})
    
    return to_js({'query_results' : Counter(result1) == Counter(result2)})

def compare_queries_with_control(connection, solution_query, user_query, control_query):
    connection.commit()
    _, _, _ = _execute_query(connection, solution_query )
    _, result1, _ = _execute_query(connection, control_query)
    connection.rollback()
    _, _, err3 = _execute_query(connection, user_query)
    if err3:
        return to_js({'error': err3})
    _, result2, err4 = _execute_query(connection, control_query)
    if err4:
        return to_js({'error': err4})
    connection.rollback()
    return to_js({'query_results' : result1 == result2})
